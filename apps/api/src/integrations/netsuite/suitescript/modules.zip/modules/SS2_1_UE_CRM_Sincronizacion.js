/**
 * Entrada global de eventos guardados del CRM. Solo enruta; la logica vive en lib y en cada modulo.
 * Archivador: /SuiteScripts/CRM TINK/modules/SS2_1_UE_CRM_Sincronizacion.js
 * Crear un despliegue por tipo de registro. Esta primera entrega solo registra diagnostico en Sandbox.
 * No envia HTTP, no crea una cola y no modifica registros: el receptor y la entrega quedan pendientes.
 *
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */
define([
    "../lib/SS2_1_LIB_CRM_Eventos",
    "./01_sales-orders/SS2_1_LIB_CRM_OrdenesVenta_NotificarCambio",
    "./02_leads/SS2_1_LIB_CRM_Leads",
    "./03_estimates/SS2_1_LIB_CRM_Estimaciones",
], (events, salesOrders, leads, estimates) => {
    "use strict";

    // Registro cerrado. Los modulos reservados no se presentan como sincronizados.
    const modules = Object.freeze({
        salesorder: { code: "salesOrders", afterSubmit: salesOrders.afterSubmit },
        lead: { code: "leads", afterSubmit: leads.afterSubmit },
        estimate: { code: "estimates", afterSubmit: estimates.afterSubmit },
        // Partner no acredita todavia el tipo real del catalogo de corredores de esta cuenta.
        partner: { code: "brokers" },
    });

    return { afterSubmit: (context) => events.afterSubmit(context, modules) };
});
