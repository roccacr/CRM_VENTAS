/**
 * Accion de ordenes de venta al guardar. Reservada para conectar el receptor autenticado del API.
 * No leer de nuevo ni enviar datos mientras no existan receptor, contrato y entrega con reintentos.
 * Archivador: /SuiteScripts/CRM TINK/modules/01_sales-orders/SS2_1_LIB_CRM_OrdenesVenta_NotificarCambio.js
 * @NApiVersion 2.1
 */
define([], () => {
    "use strict";

    /** Estado explicito: observar un guardado no significa que se haya entregado al CRM. */
    function afterSubmit() {
        return { status: "pending_api", delivered: false };
    }

    return Object.freeze({ afterSubmit });
});
